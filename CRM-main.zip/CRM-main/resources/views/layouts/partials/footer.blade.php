<footer class="main-footer">
    <strong>Copyright &copy; 2023 Todos los derechos reservados.
</footer>
